package com.citycare.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDateTime;

/**
 * ============================================================
 * Emergency.java  –  Core Workflow Entity
 * ============================================================
 *
 * Tracks the full lifecycle of one emergency incident.
 *
 * COMPLETE STATUS FLOW:
 *
 *  [Citizen]       POST /emergencies/report
 *       │           → status = REPORTED
 *       ▼
 *  [Dispatcher]    GET  /emergencies/pending        ← sees this emergency
 *  [Dispatcher]    GET  /emergencies/ambulances/available ← picks ambulance
 *  [Dispatcher]    POST /emergencies/{id}/dispatch
 *       │           → ambulance.status = DISPATCHED
 *       │           → emergency.status = DISPATCHED
 *       │           → dispatchedAt = now
 *       ▼
 *  [Admin]         GET  /emergencies/dispatched     ← sees this emergency
 *  [Admin]         POST /patients/admit
 *       │           → patient record created
 *       │           → emergency.status = ADMITTED
 *       │           → ambulance.status = AVAILABLE  ← AUTO-RELEASED
 *       ▼
 *  [Doctor/Nurse]  PATCH /patients/{id}/status → DISCHARGED
 *       │           → emergency.status = CLOSED
 *       ▼
 *                  CLOSED
 *
 * FOREIGN KEYS (set by Hibernate):
 *   citizen_id    → users.user_id   (who reported it)
 *   dispatcher_id → users.user_id   (who handled it – null until dispatched)
 *   ambulance_id  → ambulances.ambulance_id (null until dispatched)
 *
 * ============================================================
 * TABLE CREATED BY HIBERNATE:
 *   CREATE TABLE emergencies (
 *     emergency_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
 *     citizen_id     BIGINT NOT NULL,
 *     type           VARCHAR(50) NOT NULL,
 *     location       TEXT NOT NULL,
 *     description    TEXT,
 *     status         VARCHAR(50) NOT NULL DEFAULT 'REPORTED',
 *     reported_at    DATETIME(6),
 *     dispatcher_id  BIGINT,
 *     ambulance_id   BIGINT,
 *     dispatched_at  DATETIME(6),
 *     created_at     DATETIME(6) NOT NULL,
 *     updated_at     DATETIME(6),
 *     FOREIGN KEY (citizen_id)   REFERENCES users(user_id),
 *     FOREIGN KEY (dispatcher_id) REFERENCES users(user_id),
 *     FOREIGN KEY (ambulance_id)  REFERENCES ambulances(ambulance_id)
 *   );
 * ============================================================
 */
@Entity
@Table(name = "emergencies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Emergency extends BaseEntity {

    public enum Type {
        ACCIDENT,
        HEART_ATTACK,
        FIRE,
        STROKE,
        FALL,
        OTHER
    }

    public enum Status {
        REPORTED,    // Citizen submitted – waiting for dispatcher
        DISPATCHED,  // Dispatcher assigned ambulance – waiting for admin to admit
        ADMITTED,    // Admin admitted the patient to hospital
        CLOSED       // Treatment complete, case closed
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long emergencyId;

    // FetchType.LAZY = only load this User from DB when we actually access it
    // (performance optimisation – avoids unnecessary JOINs)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "citizen_id", nullable = false)
    private User citizen;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Type type;

    @NotBlank
    @Column(nullable = false, columnDefinition = "TEXT")
    private String location;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Status status = Status.REPORTED;

    @Builder.Default
    private LocalDateTime reportedAt = LocalDateTime.now();

    // These two fields are NULL until dispatcher acts
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dispatcher_id")
    private User dispatcher;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ambulance_id")
    private Ambulance ambulance;

    private LocalDateTime dispatchedAt;
}
