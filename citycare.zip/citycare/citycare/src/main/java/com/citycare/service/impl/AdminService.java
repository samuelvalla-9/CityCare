package com.citycare.service.impl;

import com.citycare.dto.request.AmbulanceRequest;
import com.citycare.dto.request.CreateStaffRequest;
import com.citycare.entity.Ambulance;
import com.citycare.entity.User;
import com.citycare.exception.BadRequestException;
import com.citycare.exception.ResourceNotFoundException;
import com.citycare.repository.AmbulanceRepository;
import com.citycare.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * AdminService.java  –  Hospital Admin Resource Management
 * ============================================================
 *
 * ADMIN is responsible for:
 *   1. Creating DOCTOR and NURSE accounts (staff)
 *   2. Creating DISPATCHER accounts
 *   3. Adding ambulances to the fleet
 *   4. Viewing/managing all resources
 *
 * There is NO self-registration for staff or dispatchers.
 * Only Admin can create these accounts.
 *
 * createStaff():
 *   Validates role is DOCTOR or NURSE (not CITIZEN/ADMIN/DISPATCHER).
 *   Hashes password with BCrypt.
 *   Saves to 'users' table – same table as citizens, different role column.
 *
 * createDispatcher():
 *   Same as createStaff() but validates role = DISPATCHER.
 *
 * addAmbulance():
 *   Prevents duplicate vehicle numbers.
 *   New ambulance starts with status = AVAILABLE (set by @Builder.Default).
 *
 * updateAmbulanceStatus():
 *   Admin can manually set an ambulance to MAINTENANCE (e.g. for servicing).
 *   Can also set back to AVAILABLE when repair is done.
 *   NOTE: do NOT use this to set DISPATCHED manually –
 *   that happens automatically through EmergencyService.dispatchAmbulance().
 *
 * ============================================================
 */
@Service
@RequiredArgsConstructor
public class AdminService {

    private final UserRepository userRepository;
    private final AmbulanceRepository ambulanceRepository;
    private final PasswordEncoder passwordEncoder;

    @Transactional
    public User createStaff(CreateStaffRequest req) {
        if (req.getRole() != User.Role.DOCTOR && req.getRole() != User.Role.NURSE) {
            throw new BadRequestException(
                    "Invalid role for staff: " + req.getRole() +
                    ". Use DOCTOR or NURSE.");
        }
        return createAccount(req);
    }

    @Transactional
    public User createDispatcher(CreateStaffRequest req) {
        if (req.getRole() != User.Role.DISPATCHER) {
            throw new BadRequestException("Role must be DISPATCHER for dispatcher accounts");
        }
        return createAccount(req);
    }

    // Shared logic for creating any non-citizen user
    private User createAccount(CreateStaffRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new BadRequestException("Email already in use: " + req.getEmail());
        }
        User user = User.builder()
                .name(req.getName())
                .email(req.getEmail())
                .password(passwordEncoder.encode(req.getPassword()))
                .role(req.getRole())
                .phone(req.getPhone())
                .build();
        return userRepository.save(user);
        // Hibernate: INSERT INTO users (name, email, password, role, ...)
    }

    @Transactional
    public Ambulance addAmbulance(AmbulanceRequest req) {
        if (ambulanceRepository.existsByVehicleNumber(req.getVehicleNumber())) {
            throw new BadRequestException(
                    "Ambulance with vehicle number " + req.getVehicleNumber() + " already exists");
        }
        Ambulance ambulance = Ambulance.builder()
                .vehicleNumber(req.getVehicleNumber())
                .model(req.getModel())
                .build(); // status = AVAILABLE by default
        return ambulanceRepository.save(ambulance);
    }

    @Transactional
    public Ambulance updateAmbulanceStatus(Long id, Ambulance.Status newStatus) {
        Ambulance ambulance = ambulanceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ambulance", id));
        ambulance.setStatus(newStatus);
        return ambulanceRepository.save(ambulance);
    }

    @Transactional
    public User deactivateUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", userId));
        user.setStatus(User.Status.INACTIVE);
        return userRepository.save(user);
    }

    public List<User> getAllStaff() {
        // Combine DOCTOR and NURSE lists
        List<User> all = new ArrayList<>(userRepository.findByRole(User.Role.DOCTOR));
        all.addAll(userRepository.findByRole(User.Role.NURSE));
        return all;
    }

    public List<User> getAllDispatchers() {
        return userRepository.findByRole(User.Role.DISPATCHER);
    }

    public List<Ambulance> getAllAmbulances() {
        return ambulanceRepository.findAll();
    }
}
