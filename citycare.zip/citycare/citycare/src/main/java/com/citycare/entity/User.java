package com.citycare.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

/**
 * ============================================================
 * User.java  –  Single table for ALL roles
 * ============================================================
 *
 * @Entity  →  Hibernate creates a table named 'users' for this class.
 * @Table   →  Customises table name + adds UNIQUE constraint on email.
 *
 * ALL roles share this ONE table:
 *   CITIZEN    → self-registers via POST /auth/register
 *   DOCTOR     → created by Admin via POST /admin/staff
 *   NURSE      → created by Admin via POST /admin/staff
 *   DISPATCHER → created by Admin via POST /admin/dispatchers
 *   ADMIN      → created by Admin (first admin seeded manually or via init)
 *
 * Role is stored as a STRING column ("CITIZEN", "DOCTOR" etc.)
 * so the DB stays readable. @Enumerated(EnumType.STRING) handles this.
 *
 * Password is ALWAYS stored as BCrypt hash – never plain text.
 * BCrypt format: $2a$12$... (60 characters)
 *
 * ============================================================
 * TABLE CREATED BY HIBERNATE:
 *   CREATE TABLE users (
 *     user_id    BIGINT AUTO_INCREMENT PRIMARY KEY,
 *     name       VARCHAR(255) NOT NULL,
 *     email      VARCHAR(255) NOT NULL UNIQUE,
 *     password   VARCHAR(255) NOT NULL,
 *     role       VARCHAR(50)  NOT NULL,
 *     phone      VARCHAR(255),
 *     status     VARCHAR(50)  NOT NULL DEFAULT 'ACTIVE',
 *     created_at DATETIME(6) NOT NULL,
 *     updated_at DATETIME(6)
 *   );
 * ============================================================
 */
@Entity
@Table(name = "users",
        uniqueConstraints = @UniqueConstraint(columnNames = "email"))
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User extends BaseEntity {

    public enum Role {
        CITIZEN,     // Reports emergencies
        DOCTOR,      // Assigns treatments, updates patient status
        NURSE,       // Assists with patient care and treatments
        DISPATCHER,  // Receives emergency alerts, assigns ambulances
        ADMIN        // Admits patients, manages all resources
    }

    public enum Status {
        ACTIVE,
        INACTIVE  // Soft-delete – account disabled, not deleted from DB
    }

    // BIGINT AUTO_INCREMENT PRIMARY KEY – Hibernate sets this automatically
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @NotBlank
    @Column(nullable = false)
    private String name;

    @Email
    @NotBlank
    @Column(nullable = false, unique = true)
    private String email;

    @NotBlank
    @Column(nullable = false)
    private String password; // BCrypt hashed – set by AuthService / AdminService

    // EnumType.STRING stores "CITIZEN" not 0/1/2 – safer if enum order changes
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    private String phone;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Status status = Status.ACTIVE;
}
