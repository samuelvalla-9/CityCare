package com.citycare.dto.request;

import com.citycare.entity.User;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * CreateStaffRequest – Body for POST /admin/staff and POST /admin/dispatchers
 * Admin creates user accounts for hospital staff and dispatchers.
 * These users cannot self-register – only Admin can create them.
 */
@Data
public class CreateStaffRequest {

    @NotBlank(message = "Name is required")
    private String name;

    @Email(message = "Valid email required")
    @NotBlank(message = "Email is required")
    private String email;

    @NotBlank(message = "Password is required")
    private String password;

    @NotNull(message = "Role is required")
    private User.Role role; // For staff: DOCTOR or NURSE. For dispatchers: DISPATCHER.

    private String phone;
}
