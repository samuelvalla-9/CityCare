package com.citycare.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

/**
 * ============================================================
 * BaseEntity.java  –  Shared Audit Fields for All Tables
 * ============================================================
 *
 * @MappedSuperclass
 *   This class is NOT a database table by itself.
 *   Its fields (createdAt, updatedAt) are MERGED into every
 *   entity class that extends it.
 *   e.g. User extends BaseEntity → the 'users' table will
 *   have columns: created_at, updated_at automatically.
 *
 * @EntityListeners(AuditingEntityListener.class)
 *   Listens to JPA lifecycle events (prePersist, preUpdate).
 *   On INSERT → fills createdAt with current timestamp.
 *   On UPDATE → fills updatedAt with current timestamp.
 *   No manual date setting needed anywhere.
 *
 * ============================================================
 * HOW THIS FILE WORKS:
 *   Every entity (User, Emergency, Patient, etc.) extends this.
 *   Hibernate automatically adds created_at and updated_at columns
 *   to each entity's table. These are filled automatically by
 *   Spring Data JPA auditing – zero code required in services.
 * ============================================================
 */
@Getter
@Setter
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public abstract class BaseEntity {

    // Set once on first INSERT. updatable=false prevents accidental overwrite.
    @CreatedDate
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // Updated automatically on every UPDATE operation
    @LastModifiedDate
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
}
