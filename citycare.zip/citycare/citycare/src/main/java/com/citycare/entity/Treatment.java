package com.citycare.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

/**
 * ============================================================
 * Treatment.java  –  Medical Treatment Record
 * ============================================================
 *
 * Assigned by DOCTOR or NURSE to an admitted patient.
 * Only DOCTOR/NURSE roles can create treatments (enforced in SecurityConfig).
 *
 * WORKFLOW:
 *   Staff calls POST /treatments with { patientId, description, ... }
 *   → Treatment created with status = ONGOING
 *
 *   Staff calls PATCH /treatments/{id}/status with ?status=COMPLETED
 *   → endDate is set automatically
 *
 * STATUS FLOW:
 *   ONGOING → COMPLETED  (procedure is done)
 *   ONGOING → CANCELLED  (treatment no longer needed)
 *
 * FOREIGN KEYS:
 *   patient_id  → patients.patient_id  (who receives treatment)
 *   assigned_by → users.user_id        (doctor or nurse who assigned it)
 *
 * ============================================================
 * TABLE CREATED BY HIBERNATE:
 *   CREATE TABLE treatments (
 *     treatment_id    BIGINT AUTO_INCREMENT PRIMARY KEY,
 *     patient_id      BIGINT NOT NULL,
 *     assigned_by     BIGINT NOT NULL,
 *     description     TEXT NOT NULL,
 *     medication_name VARCHAR(255),
 *     dosage          VARCHAR(255),
 *     start_date      DATE,
 *     end_date        DATE,
 *     status          VARCHAR(50) NOT NULL,
 *     created_at      DATETIME(6) NOT NULL,
 *     updated_at      DATETIME(6)
 *   );
 * ============================================================
 */
@Entity
@Table(name = "treatments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Treatment extends BaseEntity {

    public enum Status {
        ONGOING,    // Treatment is currently active
        COMPLETED,  // Successfully finished
        CANCELLED   // Discontinued / no longer needed
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long treatmentId;

    // The patient receiving this treatment
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "patient_id", nullable = false)
    private Patient patient;

    // The doctor or nurse who assigned this treatment
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_by", nullable = false)
    private User assignedBy;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description; // e.g. "Administer IV saline drip every 6 hours"

    private String medicationName; // e.g. "Amoxicillin"
    private String dosage;         // e.g. "500mg twice daily"

    @Builder.Default
    private LocalDate startDate = LocalDate.now();

    private LocalDate endDate; // Set when COMPLETED or CANCELLED

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Status status = Status.ONGOING;
}
