package com.citycare.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================
 * Patient.java  –  Hospital Admission Record
 * ============================================================
 *
 * A Patient record is created when ADMIN calls POST /patients/admit.
 * It links the admitted citizen to the emergency that brought them in.
 *
 * On admission (PatientService.admitPatient()):
 *   1. Patient record is created (status = ADMITTED)
 *   2. Emergency status → ADMITTED
 *   3. Ambulance status → AVAILABLE  ← auto-released!
 *
 * STATUS FLOW (updated by Doctor/Nurse via PATCH /patients/{id}/status):
 *   ADMITTED → UNDER_OBSERVATION → STABLE → DISCHARGED
 *
 * On DISCHARGED:
 *   dischargeDate is set to today
 *   Emergency status → CLOSED
 *
 * RELATIONSHIPS:
 *   @ManyToOne citizen   → one citizen can be admitted multiple times
 *   @OneToOne  emergency → one emergency leads to one patient record
 *   @OneToMany treatments → one patient has many treatments
 *     cascade = ALL:      save/delete patient also saves/deletes its treatments
 *     orphanRemoval = true: removing treatment from list deletes it from DB
 *
 * ============================================================
 * TABLE CREATED BY HIBERNATE:
 *   CREATE TABLE patients (
 *     patient_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
 *     citizen_id     BIGINT NOT NULL,
 *     emergency_id   BIGINT UNIQUE,
 *     admission_date DATE NOT NULL,
 *     discharge_date DATE,
 *     status         VARCHAR(50) NOT NULL,
 *     ward           VARCHAR(255),
 *     notes          TEXT,
 *     created_at     DATETIME(6) NOT NULL,
 *     updated_at     DATETIME(6)
 *   );
 * ============================================================
 */
@Entity
@Table(name = "patients")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Patient extends BaseEntity {

    public enum Status {
        ADMITTED,            // Just checked in by Admin
        UNDER_OBSERVATION,   // Doctors monitoring the patient
        STABLE,              // Condition is stable, less critical
        DISCHARGED           // Released – triggers emergency CLOSED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long patientId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "citizen_id", nullable = false)
    private User citizen;

    // Each emergency can result in at most ONE patient record
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "emergency_id")
    private Emergency emergency;

    @Column(nullable = false)
    private LocalDate admissionDate;

    private LocalDate dischargeDate; // null until DISCHARGED

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private Status status = Status.ADMITTED;

    private String ward;   // e.g. "ICU", "General Ward", "Cardiology"
    private String notes;  // Admission notes added by Admin

    @OneToMany(mappedBy = "patient", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Treatment> treatments = new ArrayList<>();
}
