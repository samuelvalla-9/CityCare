package com.citycare.controller;

import com.citycare.dto.request.AmbulanceRequest;
import com.citycare.dto.request.CreateStaffRequest;
import com.citycare.dto.response.ApiResponse;
import com.citycare.entity.Ambulance;
import com.citycare.entity.User;
import com.citycare.service.impl.AdminService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * ============================================================
 * AdminController.java  –  Admin Resource Management
 * ============================================================
 *
 * ALL endpoints here require ADMIN role JWT token.
 * Configured in SecurityConfig: .requestMatchers("/admin/**").hasRole("ADMIN")
 *
 * Admin is responsible for:
 *   1. Creating Doctor and Nurse accounts
 *   2. Creating Dispatcher accounts
 *   3. Adding ambulances to the fleet
 *   4. Viewing and managing all resources
 *   5. Deactivating user accounts
 *
 * IMPORTANT: There is NO self-registration for Doctor/Nurse/Dispatcher.
 * Only Admin can create those accounts using these endpoints.
 *
 * ============================================================
 * POSTMAN TESTING GUIDE  –  ALL ADMIN ENDPOINTS
 * ============================================================
 *
 * SETUP: You need an ADMIN account. Since Admin can't self-register,
 * for the first time you can insert one manually via MySQL:
 *   INSERT INTO users (name, email, password, role, status, created_at)
 *   VALUES (
 *     'Admin User',
 *     'admin@citycare.com',
 *     '$2a$12$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHi',
 *     'ADMIN',
 *     'ACTIVE',
 *     NOW()
 *   );
 *   (Password above = 'admin123' BCrypt-hashed)
 *
 * Then login: POST /auth/login → { "email": "admin@citycare.com", "password": "admin123" }
 * Copy the token and use it for all admin requests below.
 *
 * ──────────────────────────────────────────────────────────────
 * POST /admin/staff  →  Create Doctor or Nurse Account
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : POST
 * URL    : http://localhost:8080/api/admin/staff
 * HEADERS:
 *   Content-Type:  application/json
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * BODY – Create a Doctor:
 * {
 *   "name": "Dr. Priya Sharma",
 *   "email": "dr.priya@citycare.com",
 *   "password": "doc1234",
 *   "role": "DOCTOR",
 *   "phone": "9876501234"
 * }
 *
 * BODY – Create a Nurse:
 * {
 *   "name": "Nurse Anbu Selvi",
 *   "email": "nurse.anbu@citycare.com",
 *   "password": "nurse123",
 *   "role": "NURSE",
 *   "phone": "9876502345"
 * }
 *
 * VALID ROLE VALUES for staff: "DOCTOR" or "NURSE" only.
 *
 * EXPECTED RESPONSE (201 Created):
 * {
 *   "success": true,
 *   "message": "Staff account created",
 *   "data": {
 *     "userId": 3,
 *     "name": "Dr. Priya Sharma",
 *     "email": "dr.priya@citycare.com",
 *     "role": "DOCTOR",
 *     "status": "ACTIVE"
 *   }
 * }
 *
 * ERROR CASES:
 *   → 400 if role is DISPATCHER or CITIZEN or ADMIN:
 *     { "message": "Invalid role for staff: DISPATCHER. Use DOCTOR or NURSE." }
 *   → 400 if email already exists:
 *     { "message": "Email already in use: dr.priya@citycare.com" }
 *
 * ──────────────────────────────────────────────────────────────
 * POST /admin/dispatchers  →  Create Dispatcher Account
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : POST
 * URL    : http://localhost:8080/api/admin/dispatchers
 * HEADERS:
 *   Content-Type:  application/json
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * BODY:
 * {
 *   "name": "Dispatcher Kumar",
 *   "email": "disp1@citycare.com",
 *   "password": "disp123",
 *   "role": "DISPATCHER",
 *   "phone": "9876503456"
 * }
 *
 * ROLE must be "DISPATCHER" (else 400 error).
 *
 * EXPECTED RESPONSE (201 Created):
 * {
 *   "success": true,
 *   "message": "Dispatcher account created",
 *   "data": {
 *     "userId": 4,
 *     "name": "Dispatcher Kumar",
 *     "role": "DISPATCHER",
 *     "status": "ACTIVE"
 *   }
 * }
 *
 * ──────────────────────────────────────────────────────────────
 * POST /admin/ambulances  →  Add Ambulance to Fleet
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : POST
 * URL    : http://localhost:8080/api/admin/ambulances
 * HEADERS:
 *   Content-Type:  application/json
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * BODY EXAMPLE 1:
 * {
 *   "vehicleNumber": "TN-01-AB-1234",
 *   "model": "Toyota HiAce Advanced Life Support"
 * }
 *
 * BODY EXAMPLE 2:
 * {
 *   "vehicleNumber": "TN-01-CD-5678",
 *   "model": "Force Traveller BLS"
 * }
 *
 * EXPECTED RESPONSE (201 Created):
 * {
 *   "success": true,
 *   "message": "Ambulance added to fleet",
 *   "data": {
 *     "ambulanceId": 1,
 *     "vehicleNumber": "TN-01-AB-1234",
 *     "model": "Toyota HiAce Advanced Life Support",
 *     "status": "AVAILABLE"
 *   }
 * }
 *
 * ERROR: { "message": "Ambulance with vehicle number TN-01-AB-1234 already exists" }
 *
 * ──────────────────────────────────────────────────────────────
 * GET /admin/ambulances  →  List All Ambulances
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : GET
 * URL    : http://localhost:8080/api/admin/ambulances
 * HEADERS:
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * Returns all ambulances with their current status.
 * Status values: AVAILABLE, DISPATCHED, MAINTENANCE
 *
 * ──────────────────────────────────────────────────────────────
 * PATCH /admin/ambulances/{id}/status  →  Update Ambulance Status
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : PATCH
 * URL    : http://localhost:8080/api/admin/ambulances/1/status?status=MAINTENANCE
 * HEADERS:
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * NO BODY – status is a query parameter.
 *
 * USE CASES:
 *   → MAINTENANCE : Ambulance going for servicing
 *   → AVAILABLE   : Repair done, back in service
 *   (Do NOT set DISPATCHED manually – that happens via /emergencies/{id}/dispatch)
 *
 * EXAMPLE URLs:
 *   PATCH /api/admin/ambulances/1/status?status=MAINTENANCE
 *   PATCH /api/admin/ambulances/1/status?status=AVAILABLE
 *
 * ──────────────────────────────────────────────────────────────
 * GET /admin/staff  →  List All Staff (Doctors + Nurses)
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : GET
 * URL    : http://localhost:8080/api/admin/staff
 * HEADERS:
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * ──────────────────────────────────────────────────────────────
 * GET /admin/dispatchers  →  List All Dispatchers
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : GET
 * URL    : http://localhost:8080/api/admin/dispatchers
 * HEADERS:
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * ──────────────────────────────────────────────────────────────
 * PATCH /admin/users/{id}/deactivate  →  Deactivate a User
 * ──────────────────────────────────────────────────────────────
 * ROLE   : ADMIN
 * METHOD : PATCH
 * URL    : http://localhost:8080/api/admin/users/3/deactivate
 *         (Replace 3 with actual userId)
 * HEADERS:
 *   Authorization: Bearer <ADMIN_TOKEN>
 *
 * NO BODY needed. Sets user.status = INACTIVE (soft delete).
 * The user record stays in DB but login will fail next time.
 *
 * ============================================================
 */
@RestController
@RequestMapping("/admin")
@RequiredArgsConstructor
@Tag(name = "5. Admin", description = "Admin only: Create staff/dispatchers, manage ambulances. ALL require ADMIN token.")
public class AdminController {

    private final AdminService adminService;

    // ── STAFF MANAGEMENT ──────────────────────────────────────────────────────

    @PostMapping("/staff")
    @Operation(
        summary = "[ADMIN] Create Doctor or Nurse Account",
        description = """
            POSTMAN: POST http://localhost:8080/api/admin/staff
            Header: Authorization: Bearer <ADMIN_TOKEN>
            Body (Doctor):
            { "name": "Dr. Priya Sharma", "email": "dr.priya@citycare.com", "password": "doc1234", "role": "DOCTOR", "phone": "9876501234" }
            
            Body (Nurse):
            { "name": "Nurse Anbu", "email": "nurse.anbu@citycare.com", "password": "nurse123", "role": "NURSE", "phone": "9876502345" }
            
            role must be: DOCTOR or NURSE (not DISPATCHER, not CITIZEN)
            """
    )
    public ResponseEntity<ApiResponse<User>> createStaff(
            @Valid @RequestBody CreateStaffRequest request) {

        User staff = adminService.createStaff(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Staff account created", staff));
    }

    @GetMapping("/staff")
    @Operation(
        summary = "[ADMIN] List All Doctors and Nurses",
        description = "POSTMAN: GET http://localhost:8080/api/admin/staff  |  Header: Authorization: Bearer <ADMIN_TOKEN>"
    )
    public ResponseEntity<ApiResponse<List<User>>> getAllStaff() {
        return ResponseEntity.ok(ApiResponse.ok("All staff", adminService.getAllStaff()));
    }

    // ── DISPATCHER MANAGEMENT ─────────────────────────────────────────────────

    @PostMapping("/dispatchers")
    @Operation(
        summary = "[ADMIN] Create Dispatcher Account",
        description = """
            POSTMAN: POST http://localhost:8080/api/admin/dispatchers
            Header: Authorization: Bearer <ADMIN_TOKEN>
            Body:
            { "name": "Dispatcher Kumar", "email": "disp1@citycare.com", "password": "disp123", "role": "DISPATCHER", "phone": "9876503456" }
            
            role must be: DISPATCHER
            """
    )
    public ResponseEntity<ApiResponse<User>> createDispatcher(
            @Valid @RequestBody CreateStaffRequest request) {

        User dispatcher = adminService.createDispatcher(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Dispatcher account created", dispatcher));
    }

    @GetMapping("/dispatchers")
    @Operation(
        summary = "[ADMIN] List All Dispatchers",
        description = "POSTMAN: GET http://localhost:8080/api/admin/dispatchers  |  Header: Authorization: Bearer <ADMIN_TOKEN>"
    )
    public ResponseEntity<ApiResponse<List<User>>> getAllDispatchers() {
        return ResponseEntity.ok(ApiResponse.ok("All dispatchers", adminService.getAllDispatchers()));
    }

    // ── AMBULANCE MANAGEMENT ──────────────────────────────────────────────────

    @PostMapping("/ambulances")
    @Operation(
        summary = "[ADMIN] Add Ambulance to Fleet",
        description = """
            POSTMAN: POST http://localhost:8080/api/admin/ambulances
            Header: Authorization: Bearer <ADMIN_TOKEN>
            Body:
            { "vehicleNumber": "TN-01-AB-1234", "model": "Toyota HiAce ALS" }
            
            New ambulance always starts with status = AVAILABLE.
            """
    )
    public ResponseEntity<ApiResponse<Ambulance>> addAmbulance(
            @Valid @RequestBody AmbulanceRequest request) {

        Ambulance ambulance = adminService.addAmbulance(request);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Ambulance added to fleet", ambulance));
    }

    @GetMapping("/ambulances")
    @Operation(
        summary = "[ADMIN] List All Ambulances with Status",
        description = "POSTMAN: GET http://localhost:8080/api/admin/ambulances  |  Header: Authorization: Bearer <ADMIN_TOKEN>"
    )
    public ResponseEntity<ApiResponse<List<Ambulance>>> getAllAmbulances() {
        return ResponseEntity.ok(ApiResponse.ok("All ambulances", adminService.getAllAmbulances()));
    }

    @PatchMapping("/ambulances/{id}/status")
    @Operation(
        summary = "[ADMIN] Update Ambulance Status (MAINTENANCE / AVAILABLE)",
        description = """
            POSTMAN: PATCH http://localhost:8080/api/admin/ambulances/1/status?status=MAINTENANCE
            Header: Authorization: Bearer <ADMIN_TOKEN>
            No body needed. Status is a query param.
            
            Use MAINTENANCE when vehicle is being serviced.
            Use AVAILABLE when repair is done.
            Do NOT set DISPATCHED manually – that's done via the dispatch endpoint.
            
            Valid values: AVAILABLE | MAINTENANCE
            """
    )
    public ResponseEntity<ApiResponse<Ambulance>> updateAmbulanceStatus(
            @PathVariable Long id,
            @RequestParam Ambulance.Status status) {

        Ambulance ambulance = adminService.updateAmbulanceStatus(id, status);
        return ResponseEntity.ok(ApiResponse.ok("Ambulance status updated to " + status, ambulance));
    }

    // ── USER MANAGEMENT ───────────────────────────────────────────────────────

    @PatchMapping("/users/{id}/deactivate")
    @Operation(
        summary = "[ADMIN] Deactivate a User Account",
        description = """
            POSTMAN: PATCH http://localhost:8080/api/admin/users/3/deactivate
            Header: Authorization: Bearer <ADMIN_TOKEN>
            No body needed. Replace '3' with actual userId.
            
            Sets user.status = INACTIVE (soft delete, keeps DB record).
            The user can no longer log in after this.
            """
    )
    public ResponseEntity<ApiResponse<User>> deactivateUser(@PathVariable Long id) {
        User user = adminService.deactivateUser(id);
        return ResponseEntity.ok(ApiResponse.ok("User deactivated successfully", user));
    }
}
