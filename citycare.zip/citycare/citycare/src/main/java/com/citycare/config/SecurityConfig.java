package com.citycare.config;

import com.citycare.security.JwtAuthFilter;
import com.citycare.security.UserDetailsServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

/**
 * ============================================================
 * SecurityConfig.java  –  Security Rules and JWT Setup
 * ============================================================
 *
 * KEY CONCEPTS EXPLAINED:
 *
 * STATELESS SESSION:
 *   We don't store any session on the server. Every request must
 *   carry its own JWT token. This is the standard for REST APIs.
 *   SessionCreationPolicy.STATELESS enforces this.
 *
 * CSRF DISABLED:
 *   CSRF attacks require session cookies. Since we use stateless JWT,
 *   CSRF is not a threat here. Disabling it simplifies API testing.
 *
 * CORS:
 *   Allows the React/Angular frontend (on port 3000/4200/5173)
 *   to call this API (port 8080) from a browser without being blocked.
 *
 * PASSWORD ENCODING:
 *   BCryptPasswordEncoder hashes passwords with a random salt.
 *   Cost factor 12 = ~250ms per hash (slow enough to resist brute force).
 *   NEVER store plain-text passwords.
 *
 * ROLE ACCESS RULES:
 *   /auth/**                          → Public (no token needed)
 *   /emergencies/report               → CITIZEN only
 *   /emergencies/pending              → DISPATCHER only
 *   /emergencies/ambulances/available → DISPATCHER only
 *   /emergencies/dispatch           → DISPATCHER only
 *   /emergencies/dispatched           → ADMIN only
 *   /patients/admit                   → ADMIN only
 *   /admin/**                         → ADMIN only
 *   /treatments/**                    → DOCTOR or NURSE
 *   Everything else                   → any authenticated user
 *
 * ============================================================
 * HOW THIS FILE WORKS:
 *   Spring reads this at startup and builds the security filter chain.
 *   JwtAuthFilter is inserted before Spring's default auth filter.
 *   Every request: JwtAuthFilter runs first → sets auth context →
 *   then these rules decide if access is granted (403 if not).
 * ============================================================
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final UserDetailsServiceImpl userDetailsService;
    private final JwtAuthFilter jwtAuthFilter;

    // BCrypt with strength 12 – used to hash passwords on save and verify on login
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(12);
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    // Used by AuthService to authenticate login requests
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authorizeHttpRequests(auth -> auth
                // ── PUBLIC (no token needed) ───────────────────────────────
                .requestMatchers(
                        "/auth/**",
                        "/swagger-ui/**",
                        "/swagger-ui.html",
                        "/v3/api-docs/**"
                ).permitAll()

                // ── CITIZEN ────────────────────────────────────────────────
                .requestMatchers("/emergencies/report").hasRole("CITIZEN")
                .requestMatchers("/emergencies/my").hasRole("CITIZEN")

                // ── DISPATCHER ─────────────────────────────────────────────
                .requestMatchers("/emergencies/pending").hasRole("DISPATCHER")
                .requestMatchers("/emergencies/ambulances/available").hasRole("DISPATCHER")
                .requestMatchers("/emergencies/*/dispatch").hasRole("DISPATCHER")

                // ── ADMIN ──────────────────────────────────────────────────
                .requestMatchers("/emergencies/dispatched").hasRole("ADMIN")
                .requestMatchers("/patients/admit").hasRole("ADMIN")
                .requestMatchers("/admin/**").hasRole("ADMIN")

                // ── DOCTOR / NURSE ─────────────────────────────────────────
                .requestMatchers("/treatments/**").hasAnyRole("DOCTOR", "NURSE")

                // ── ANY AUTHENTICATED USER (GET patient details etc.) ──────
                .anyRequest().authenticated()
            )
            .authenticationProvider(authenticationProvider())
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        // Allow all common frontend dev ports
      config.setAllowedOriginPatterns(List.of("*"));
    config.setAllowedMethods(List.of("GET","POST","PUT","PATCH","DELETE","OPTIONS"));
    config.setAllowedHeaders(List.of("*"));
    config.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }
}
