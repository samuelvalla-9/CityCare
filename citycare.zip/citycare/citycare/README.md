# 🏥 CityCare – Urban Healthcare & Emergency Response System

## ⚠️ Java Version Note
> **Java 25 does not exist yet.** The latest **stable LTS** is **Java 21** (released Sept 2023).  
> Java 25 is expected in September 2026.  
> This project uses **Java 21 + Spring Boot 3.3.4** — the most current stable combination.

---

## Tech Stack

| Component | Version |
|---|---|
| Java | **21 (Latest LTS)** |
| Spring Boot | 3.3.4 |
| ORM | **Hibernate 6** (Jakarta Persistence) – auto-creates tables |
| Security | Spring Security 6 + JWT (HS256) |
| Database | MySQL 8+ |
| Build | Maven 3.8+ |
| API Docs | Swagger UI (SpringDoc OpenAPI 2) |

---

## 🗄️ Hibernate – No Manual SQL

`spring.jpa.hibernate.ddl-auto=update` in `application.properties` means:

> **Hibernate reads all `@Entity` classes → automatically creates/updates MySQL tables**

Tables auto-created:

| Table | Entity | Key Columns |
|---|---|---|
| `users` | `User.java` | user_id, name, email, password, role, status |
| `ambulances` | `Ambulance.java` | ambulance_id, vehicle_number, model, status |
| `emergencies` | `Emergency.java` | emergency_id, citizen_id, type, location, status, ambulance_id, dispatcher_id |
| `patients` | `Patient.java` | patient_id, citizen_id, emergency_id, ward, status, admission_date |
| `treatments` | `Treatment.java` | treatment_id, patient_id, assigned_by, description, medication_name, status |

---

## 🔁 Full Workflow

```
STEP 1 – Citizen
  POST /auth/register  → Citizen creates account
  POST /auth/login     → Gets JWT token
  POST /emergencies/report  → Reports emergency
  
       Emergency status: REPORTED
       ↓ Dispatcher dashboard polls GET /emergencies/pending

STEP 2 – Dispatcher
  POST /auth/login    → Gets JWT token  
  GET  /emergencies/pending              → Sees incoming emergencies (like alert)
  GET  /emergencies/ambulances/available → Picks an available ambulance
  POST /emergencies/{id}/dispatch        → Assigns ambulance
  
       Ambulance: AVAILABLE → DISPATCHED
       Emergency: REPORTED  → DISPATCHED
       ↓ Admin dashboard polls GET /emergencies/dispatched

STEP 3 – Admin
  POST /auth/login  → Gets JWT token
  GET  /emergencies/dispatched  → Sees dispatched emergencies (like alert)
  POST /patients/admit          → Admits citizen as patient
  
       Patient created: status = ADMITTED
       Emergency: DISPATCHED → ADMITTED
       ★ Ambulance: DISPATCHED → AVAILABLE  (auto-released!)

STEP 4 – Doctor / Nurse
  POST /auth/login  → Gets JWT token
  GET  /patients    → Sees admitted patients
  POST /treatments  → Assigns treatment
  PATCH /patients/{id}/status?status=STABLE      → Update condition
  PATCH /patients/{id}/status?status=DISCHARGED  → Discharge patient
  
       Emergency: ADMITTED → CLOSED (on discharge)
```

---

## 🚀 Quick Start

### 1. MySQL Setup
```sql
-- Option A: MySQL creates it automatically (createDatabaseIfNotExist=true in properties)
-- Option B: Create manually:
CREATE DATABASE citycare_db;
```

### 2. Update Credentials
Edit `src/main/resources/application.properties`:
```properties
spring.datasource.username=root
spring.datasource.password=root
```

### 3. Create First Admin User (Manual SQL – only once)
Since Admin can't self-register, insert the first admin directly:
```sql
INSERT INTO users (name, email, password, role, status, created_at)
VALUES (
  'Admin User',
  'admin@citycare.com',
  '$2a$12$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHi',
  'ADMIN',
  'ACTIVE',
  NOW()
);
-- Password = 'admin123' (BCrypt hashed above)
```

### 4. Run the App
```bash
mvn clean install
mvn spring-boot:run
```

### 5. Swagger UI
Open: **http://localhost:8080/api/swagger-ui.html**

---

## 📮 Complete Postman Testing Guide

### Setup (do this once)
1. Open Postman → New Collection → Name: "CityCare"
2. Set Base URL variable: `http://localhost:8080/api`

---

### PHASE 1 – Admin Setup

**Step A: Login as Admin**
```
POST http://localhost:8080/api/auth/login
Body: { "email": "admin@citycare.com", "password": "admin123" }
→ Copy the "token" from response
```

**Step B: Add Ambulances**
```
POST http://localhost:8080/api/admin/ambulances
Header: Authorization: Bearer <ADMIN_TOKEN>
Body: { "vehicleNumber": "TN-01-AB-1234", "model": "Toyota HiAce ALS" }
```
```
POST http://localhost:8080/api/admin/ambulances
Body: { "vehicleNumber": "TN-01-CD-5678", "model": "Force Traveller BLS" }
```

**Step C: Create Dispatcher Account**
```
POST http://localhost:8080/api/admin/dispatchers
Header: Authorization: Bearer <ADMIN_TOKEN>
Body: { "name": "Dispatcher Kumar", "email": "disp1@citycare.com", "password": "disp123", "role": "DISPATCHER" }
```

**Step D: Create Doctor and Nurse**
```
POST http://localhost:8080/api/admin/staff
Header: Authorization: Bearer <ADMIN_TOKEN>
Body: { "name": "Dr. Priya Sharma", "email": "dr.priya@citycare.com", "password": "doc1234", "role": "DOCTOR" }
```
```
POST http://localhost:8080/api/admin/staff
Body: { "name": "Nurse Anbu", "email": "nurse.anbu@citycare.com", "password": "nurse123", "role": "NURSE" }
```

---

### PHASE 2 – Citizen Registers and Reports Emergency

**Step E: Citizen Registers**
```
POST http://localhost:8080/api/auth/register
Body: { "name": "Ravi Kumar", "email": "ravi@gmail.com", "password": "ravi1234", "phone": "9876543210" }
→ Copy the "token"
```

**Step F: Citizen Reports Emergency**
```
POST http://localhost:8080/api/emergencies/report
Header: Authorization: Bearer <CITIZEN_TOKEN>
Body:
{
  "type": "ACCIDENT",
  "location": "Anna Nagar, Chennai - Near Metro Station",
  "description": "Road accident, 2 people injured, need immediate help"
}
→ Note the "emergencyId" (e.g. 1)
```

---

### PHASE 3 – Dispatcher Handles Emergency

**Step G: Dispatcher Logs In**
```
POST http://localhost:8080/api/auth/login
Body: { "email": "disp1@citycare.com", "password": "disp123" }
→ Copy the "token"
```

**Step H: View Pending Emergencies (Dispatcher Alert)**
```
GET http://localhost:8080/api/emergencies/pending
Header: Authorization: Bearer <DISPATCHER_TOKEN>
→ See emergency with id=1, status=REPORTED
```

**Step I: Check Available Ambulances**
```
GET http://localhost:8080/api/emergencies/ambulances/available
Header: Authorization: Bearer <DISPATCHER_TOKEN>
→ See ambulanceId=1 (TN-01-AB-1234, AVAILABLE)
```

**Step J: Dispatch Ambulance**
```
POST http://localhost:8080/api/emergencies/1/dispatch
Header: Authorization: Bearer <DISPATCHER_TOKEN>
Body: { "ambulanceId": 1 }
→ ambulance TN-01-AB-1234 status: AVAILABLE → DISPATCHED
→ emergency status: REPORTED → DISPATCHED
```

---

### PHASE 4 – Admin Admits Patient

**Step K: Admin Views Dispatched Emergencies (Admin Alert)**
```
GET http://localhost:8080/api/emergencies/dispatched
Header: Authorization: Bearer <ADMIN_TOKEN>
→ See emergency id=1, status=DISPATCHED, ambulance info attached
```

**Step L: Admin Admits Patient**
```
POST http://localhost:8080/api/patients/admit
Header: Authorization: Bearer <ADMIN_TOKEN>
Body:
{
  "emergencyId": 1,
  "ward": "ICU",
  "notes": "Patient arrived conscious. BP 140/90. Fracture suspected in left leg."
}
→ Patient created (status: ADMITTED)
→ Emergency: DISPATCHED → ADMITTED
→ ★ Ambulance TN-01-AB-1234: DISPATCHED → AVAILABLE (auto-released!)
```

---

### PHASE 5 – Doctor Assigns Treatment

**Step M: Doctor Logs In**
```
POST http://localhost:8080/api/auth/login
Body: { "email": "dr.priya@citycare.com", "password": "doc1234" }
```

**Step N: View Patients**
```
GET http://localhost:8080/api/patients
Header: Authorization: Bearer <DOCTOR_TOKEN>
→ Note patientId (e.g. 1)
```

**Step O: Assign Treatment**
```
POST http://localhost:8080/api/treatments
Header: Authorization: Bearer <DOCTOR_TOKEN>
Body:
{
  "patientId": 1,
  "description": "Administer IV antibiotics every 8 hours for 5 days",
  "medicationName": "Amoxicillin",
  "dosage": "500mg IV every 8 hours"
}
```

**Step P: Update Patient Status**
```
PATCH http://localhost:8080/api/patients/1/status?status=STABLE
Header: Authorization: Bearer <DOCTOR_TOKEN>
```

**Step Q: Complete Treatment**
```
PATCH http://localhost:8080/api/treatments/1/status?status=COMPLETED
Header: Authorization: Bearer <DOCTOR_TOKEN>
```

**Step R: Discharge Patient**
```
PATCH http://localhost:8080/api/patients/1/status?status=DISCHARGED
Header: Authorization: Bearer <DOCTOR_TOKEN>
→ dischargeDate = today
→ Emergency status: ADMITTED → CLOSED (case complete)
```

---

## 🔐 Role Access Summary

| Role | Access |
|---|---|
| **CITIZEN** | Register, login, report emergency, view own history |
| **DISPATCHER** | Login, view pending emergencies, view available ambulances, dispatch ambulance |
| **ADMIN** | Login, view dispatched emergencies, admit patients, create staff/dispatchers, manage ambulances |
| **DOCTOR** | Login, view patients, assign treatments, update patient/treatment status |
| **NURSE** | Same as DOCTOR |

---

## 📁 Project Structure

```
src/main/java/com/citycare/
│
├── CityCareApplication.java          ← App entry point (@SpringBootApplication)
│
├── config/
│   ├── SecurityConfig.java           ← JWT + role access rules
│   └── SwaggerConfig.java            ← Swagger UI setup
│
├── entity/                           ← @Entity = Hibernate creates DB tables
│   ├── BaseEntity.java               ← createdAt, updatedAt (shared)
│   ├── User.java                     ← users table (all roles)
│   ├── Ambulance.java                ← ambulances table
│   ├── Emergency.java                ← emergencies table (core workflow)
│   ├── Patient.java                  ← patients table
│   └── Treatment.java                ← treatments table
│
├── repository/                       ← Spring Data JPA (zero SQL needed)
│   ├── UserRepository.java
│   ├── AmbulanceRepository.java
│   ├── EmergencyRepository.java
│   ├── PatientRepository.java
│   └── TreatmentRepository.java
│
├── service/impl/                     ← Business logic
│   ├── AuthService.java              ← Registration + login
│   ├── EmergencyService.java         ← Steps 1 & 2
│   ├── PatientService.java           ← Step 3 (+ ambulance auto-release)
│   ├── TreatmentService.java         ← Step 4
│   └── AdminService.java             ← Resource management
│
├── controller/                       ← REST API endpoints
│   ├── AuthController.java           ← /auth/**
│   ├── EmergencyController.java      ← /emergencies/**
│   ├── PatientController.java        ← /patients/**
│   ├── TreatmentController.java      ← /treatments/**
│   └── AdminController.java          ← /admin/**
│
├── dto/
│   ├── request/                      ← Request body classes
│   └── response/                     ← ApiResponse, AuthResponse
│
├── exception/                        ← Error handling
│   ├── ResourceNotFoundException.java
│   ├── BadRequestException.java
│   └── GlobalExceptionHandler.java
│
└── security/                         ← JWT internals
    ├── JwtUtils.java
    ├── JwtAuthFilter.java
    └── UserDetailsServiceImpl.java
```

---

## ⚡ Key Business Rules

1. **No self-registration for staff/dispatchers** – Only Admin creates these accounts
2. **Ambulance auto-released** – When Admin admits patient → ambulance automatically returns to AVAILABLE
3. **No Notification entity** – Frontend polls `/emergencies/pending` (dispatcher alert) and `/emergencies/dispatched` (admin alert)
4. **Dispatcher cannot dispatch already-dispatched ambulance** – Returns 400 error with clear message
5. **Cannot treat discharged patient** – Returns 400 error
6. **All passwords BCrypt hashed** – Never stored in plain text
