
const API="http://localhost:8080/api";

function token(){
return localStorage.getItem("token");
}

async function login(){

const email=document.getElementById("email").value;
const password=document.getElementById("password").value;

const res=await fetch(API+"/auth/login",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({email,password})
});

const data=await res.json();

if(!data.success){
alert(data.message);
return;
}

localStorage.setItem("token",data.data.token);
localStorage.setItem("role",data.data.role);

if(data.data.role==="ADMIN") location="admin.html";
if(data.data.role==="DISPATCHER") location="dispatcher.html";
if(data.data.role==="CITIZEN") location="citizen.html";
if(data.data.role==="DOCTOR") location="doctor.html";
if(data.data.role==="NURSE") location="doctor.html";
}

async function register(){

const name=document.getElementById("name").value;
const email=document.getElementById("email").value;
const password=document.getElementById("password").value;
const phone=document.getElementById("phone").value;

await fetch(API+"/auth/register",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify({name,email,password,phone})
});

document.getElementById("msg").innerText="Registered successfully";
}

async function reportEmergency(){

const type=document.getElementById("type").value;
const location=document.getElementById("location").value;
const description=document.getElementById("description").value;

await fetch(API+"/emergencies/report",{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":"Bearer "+token()
},
body:JSON.stringify({type,location,description})
});

alert("Emergency reported");
}

async function loadMyEmergencies(){

const res=await fetch(API+"/emergencies/my",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();

const list=document.getElementById("emergencyList");
list.innerHTML="";

data.data.forEach(e=>{
const li=document.createElement("li");
li.innerText=e.type+" - "+e.location+" ("+e.status+")";
list.appendChild(li);
});
}

async function loadPending(){

const res=await fetch(API+"/emergencies/pending",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();

const list=document.getElementById("pendingList");
list.innerHTML="";

data.data.forEach(e=>{
const li=document.createElement("li");
li.innerText="ID:"+e.emergencyId+" | "+e.location;
list.appendChild(li);
});
}

async function loadAvailableAmbulances(){

const res=await fetch(API+"/emergencies/ambulances/available",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();

const list=document.getElementById("ambulanceList");
list.innerHTML="";

data.data.forEach(a=>{
const li=document.createElement("li");
li.innerText=a.vehicleNumber+" ("+a.status+")";
list.appendChild(li);
});
}

async function addAmbulance(){

const vehicleNumber=document.getElementById("vehicleNumber").value;
const model=document.getElementById("model").value;

await fetch(API+"/admin/ambulances",{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":"Bearer "+token()
},
body:JSON.stringify({vehicleNumber,model})
});

alert("Ambulance added");
}

async function addStaff(){

const name=document.getElementById("staffName").value;
const email=document.getElementById("staffEmail").value;
const password=document.getElementById("staffPassword").value;
const role=document.getElementById("staffRole").value;
const phone=document.getElementById("staffPhone").value;

await fetch(API+"/admin/staff",{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":"Bearer "+token()
},
body:JSON.stringify({name,email,password,role,phone})
});

alert("Staff created");
}

async function addDispatcher(){

const name=document.getElementById("dispName").value;
const email=document.getElementById("dispEmail").value;
const password=document.getElementById("dispPassword").value;
const phone=document.getElementById("dispPhone").value;

await fetch(API+"/admin/dispatchers",{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":"Bearer "+token()
},
body:JSON.stringify({name,email,password,role:"DISPATCHER",phone})
});

alert("Dispatcher created");
}

async function loadAmbulances(){

const res=await fetch(API+"/admin/ambulances",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();
showList(data.data);
}

async function loadStaff(){

const res=await fetch(API+"/admin/staff",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();
showList(data.data);
}

async function loadDispatchers(){

const res=await fetch(API+"/admin/dispatchers",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();
showList(data.data);
}

async function loadDispatched(){

const res=await fetch(API+"/emergencies/dispatched",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();
showList(data.data);
}

async function loadPatients(){

const res=await fetch(API+"/patients",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();
showList(data.data);
}

async function loadMyTreatments(){

const res=await fetch(API+"/treatments/mine",{
headers:{"Authorization":"Bearer "+token()}
});

const data=await res.json();
showList(data.data);
}

async function assignTreatment(){

const patientId=document.getElementById("patientId").value;
const description=document.getElementById("treatmentDesc").value;
const medicationName=document.getElementById("medication").value;
const dosage=document.getElementById("dosage").value;

await fetch(API+"/treatments",{
method:"POST",
headers:{
"Content-Type":"application/json",
"Authorization":"Bearer "+token()
},
body:JSON.stringify({
patientId:Number(patientId),
description,
medicationName,
dosage
})
});

alert("Treatment assigned");
}

function showList(data){

const list=document.getElementById("list");
if(!list) return;

list.innerHTML="";

data.forEach(item=>{
const li=document.createElement("li");
li.innerText=JSON.stringify(item);
list.appendChild(li);
});
}
